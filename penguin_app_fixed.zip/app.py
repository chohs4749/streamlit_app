import streamlit as st
from penguins import PENGUINS
st.set_page_config(page_title="🐧 Penguin Finder",page_icon="🐧",layout="wide")
st.markdown("""
<style>
.stApp{background:#eaf7ff}
.card{background:white;padding:20px;border-radius:15px;border:2px solid #9ad;}
</style>""",unsafe_allow_html=True)
st.title("🐧 Penguin Finder")
q=st.text_input("펭귄 이름을 입력하세요")
if q:
    result=None
    for n,d in PENGUINS.items():
        if q.lower() in n.lower():
            result=(n,d);break
    if result:
        n,d=result
        st.markdown(f"<div class='card'><h2>{n}</h2>",unsafe_allow_html=True)
        for k,v in d.items():
            st.write(f"**{k}**: {v}")
        st.markdown("</div>",unsafe_allow_html=True)
    else:
        st.warning("검색 결과가 없습니다.")
else:
    st.info("예: 황제펭귄, 젠투펭귄")
